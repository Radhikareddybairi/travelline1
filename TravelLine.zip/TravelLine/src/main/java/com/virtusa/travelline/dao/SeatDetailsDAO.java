package com.virtusa.travelline.dao;

public interface SeatDetailsDAO {

}
