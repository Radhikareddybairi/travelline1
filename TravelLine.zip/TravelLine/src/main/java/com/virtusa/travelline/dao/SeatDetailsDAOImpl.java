package com.virtusa.travelline.dao;

public class SeatDetailsDAOImpl {

}
