package com.virtusa.travelline.service;

public interface SeatDetailsService {

}
