package com.virtusa.travelline.service;

public class SeatDetailsServiceImpl {

}
